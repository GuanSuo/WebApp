(function(angular) {
  'use strict';
	angular.module('profile', ['lang'])
	.component('profile', {
		templateUrl: 'sourse/view/Profileview.html',
	});


})(window.angular);