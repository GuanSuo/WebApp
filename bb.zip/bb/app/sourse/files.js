(function(angular) {
  'use strict';
	angular.module('files', ['lang'])
	.component('files', {
		templateUrl: 'sourse/view/FileSystem.html',
		
	});


})(window.angular);