(function(angular) {
  'use strict';
angular.module('admin', ['lang'])
  .component('admin', {
    templateUrl: 'sourse/view/Administration.html',
	controller: 'Language'
  });


})(window.angular);