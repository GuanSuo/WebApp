(function(angular) {
  'use strict';
angular.module('registration', ['lang'])
  .component('registration', {
    templateUrl:'sourse/view/RegistrationView.html'
		
  });


})(window.angular);