(function(angular) {
  'use strict';
angular.module('search', ['lang'])
  .component('search', {
    templateUrl: 'sourse/view/SearchView.html'
  });


})(window.angular);