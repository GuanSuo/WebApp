(function(angular) {
  'use strict';
angular.module('login', ['lang'])
  .component('login', {
    templateUrl: 'sourse/view/LoginView.html'
		
  });


})(window.angular);